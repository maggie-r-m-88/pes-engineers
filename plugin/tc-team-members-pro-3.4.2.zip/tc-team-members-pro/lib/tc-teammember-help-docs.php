


<div class="wrap" style="background-color:#fff; padding:40px 30px;">

  <h3 style="padding-left:0">TC Team Members - PRO</h3>
  <p>
    <strong> Thank you for purchasing  the TC Team Members - PRO Plugin.</strong>
  </p>
  <br>
<p>
<a class="tc-button tc-btn-green" href="https://www.themescode.com/items/tc-team-members" target="_blank">Plugin Home</a>
<a class="tc-button tc-btn-orange" href="http://teammembers.themescode.com/" target="_blank">Live Preview</a>
 <a class="tc-button tc-btn-blue" href="http://themescode.com/support/" target="_blank">Support Link</a>
 <a class="tc-button tc-btn-lime" href="http://docs.themescode.com/tc-team-members-pro/" target="_blank">Documentation</a>
 <a class="tc-button tc-btn-blue" href="mailto:support@themescode.com">Email Us</a>
</p>
<br><br>
<p>
<strong>  If you have any idea to improve the quality of the product or You need any featues to add .
  Please feel free to inform. We would appreciate Your Opinion .</strong>
</p>

<p>
 <a class="tc-button tc-btn-green" href="http://themescode.com/contact/" target="_blank">Your Opinion ? </a>
</p>
</div> <!-- wrap end  -->
