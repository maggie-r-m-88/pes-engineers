<?php
/**
 * Plugin Name:		   TC Team Members Pro
 * Plugin URI:		   https://www.themescode.com/items/tc-team-members/
 * Description:		   TC Team Members plugin is fully responsive and perfectly present  team members  profiles information with social media links using our shortcode on your website.
 * Version: 		     3.6
 * Author: 			     themesCode
 * Author URI: 		   https://www.themescode.com/items/tc-team-members/
 * Text Domain:      tc-team-members
 */
 require_once('loader.php');
