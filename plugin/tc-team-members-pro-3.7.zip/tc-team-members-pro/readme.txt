=== TC Team Members Pro ===
Contributors: imranemu
Author Url : https://www.themescode.com/items/tc-team-members/
Tags: Team Member, Team Members , Teams , meet the team, members profiles,team,team plugin wordpress
Requires at least: 3.0.1
Tested up to: 5.0.3
Stable tag: 4.8

== Description ==

TC Team Members plugin is fully responsive and perfectly present  team members  profiles information with social media links using our shortcode on your website.



Contact :
support@themescode.com



=== Changelog ===

April 16, 2019
=> Email ID , Telephone Number Field Added

February 07, 2019

=> WYSIWYG editor issue solved

December 20, 2018

=> POP UP issue fixed for DIVI theme

October 16, 2018  . Version 3.4.2

=> Job Roll overlap issue solved.

September 21, 2018  . Version 3.4.1
 => Core Framework CMB2 update

September 06, 2018  . Version 3.4

=> layout 4 responsive issue solve
=> Description character number

August 17, 2018  . Version 3.3

=> Hover Icons Select options Added

August 16, 2018  . Version 3.2

=> Background Transparency Rate setting option issue solved.


February 27 , 2018 . Version 2.9.2

=> CSS bux fix to fit the POP UP box


April 1, 2017 v2.6

=> Repeatable WYSIWYG field issue solved.

April 1, 2017 v2.4

=> POP Up Size setting.
=> POP Up Image responsive.



13 October 2016 - v1.9.7

=> Layout 4 Mobile portrait Responsive Issue solved.
=> 'I Am' prefix can be Hide/show.

10th August 2016 - v1.9

=> POP up responsive issue is solved

11th July 2016 - v1.9
=> Team Member's more Details can be shown in a Pop-up window.

=> Nice Pop-up window when clicking on an image or view button.

=> remove short description from on mouse hover

15th May 2016 - v1.8
=> Email & web Icon added

=> 12 New Social Icons Added

=> any link can be added in the description area.

=> Name Fiels has been required

29th March 2016 - v1.7
=> 5 Nice Image Hover Effects
=> Overlay effects for Layout Style 5 & Layout Style 6
=> Background Color Hover Effects

27th February 2016 - v1.6

=> Total 10 Social Icon added
=> 4 social Icons can be added from 10.
=> New layout style 7 added

=> layout style 1 Transparent Background color on Hover
=> Text , title hover color

29th January 2016 - v1.0.4

=> Hide /Show Individual Social Icons.
Please add the Social media URL in the respective fields . If you do not want to show Facebook ,
for example , just keep it blank. then the facebook icon won't be dispayed !

21 Dec 2015 - v1.0.3

-> Added check box to Hide & show social Icons .

21 Dec 2015 - v1.0.2

* Pro Version Released With

-> 5 Different Layouts
-> Styling Fonts color , background color & Text Alignment.
-> 6 Different Style for Social Icons

7 Dec 2015 - v1.0.0
